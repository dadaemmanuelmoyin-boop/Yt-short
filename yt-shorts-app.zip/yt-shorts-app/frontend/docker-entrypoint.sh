#!/bin/sh
# Runs automatically at container start (nginx's official image executes
# every script in /docker-entrypoint.d/ before starting nginx).
set -e

API_BASE_URL="${API_BASE_URL:-http://localhost:8000}"

sed -i "s|__API_BASE__|${API_BASE_URL}|g" /usr/share/nginx/html/config.js

echo "frontend: API_BASE_URL set to ${API_BASE_URL}"
