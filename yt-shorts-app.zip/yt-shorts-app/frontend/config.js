// Overwritten at container startup (see docker-entrypoint.sh) with the real
// backend URL from the API_BASE_URL environment variable.
window.API_BASE = "__API_BASE__";
