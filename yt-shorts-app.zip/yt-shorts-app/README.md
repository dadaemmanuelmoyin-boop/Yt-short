# YouTube → Shorts

Paste a YouTube URL, get back auto-edited 9:16 clips with burned-in captions.

**Pipeline:** `yt-dlp` (download) → `faster-whisper` (transcribe, word timestamps)
→ OpenAI (pick the best clip candidates from the transcript) → `ffmpeg`
(crop/blur-pad to 9:16, burn captions).

## Requirements

- Python 3.10+
- `ffmpeg` installed and on your PATH (`brew install ffmpeg` / `apt install ffmpeg`)
- An OpenAI API key (or swap `clip_selector.py` for another provider — it's one
  isolated function)
- A GPU is optional. `faster-whisper` runs fine on CPU with the `small` model;
  it's just slower. Change the model size in `transcriber.py` (`tiny`, `base`,
  `small`, `medium`, `large-v3`) to trade speed for accuracy.

## Setup

```bash
cd backend
python -m venv venv
source venv/bin/activate       # Windows: venv\Scripts\activate
pip install -r requirements.txt

export OPENAI_API_KEY=sk-...   # or put it in backend/.env as OPENAI_API_KEY=sk-...

uvicorn app.main:app --reload --port 8000
```

Then just open `frontend/index.html` in a browser (no build step — it's a
static file that talks to `http://localhost:8000`). If you serve the frontend
from a different origin/port, edit `API_BASE` at the top of the `<script>` tag.

## Running with Docker

```bash
cp .env.example .env
# edit .env: set OPENAI_API_KEY, and API_BASE_URL if deploying (not just local)

docker compose up --build
```

- Backend: `http://localhost:8000`
- Frontend: `http://localhost:8080`

Rendered clips persist in a named volume (`clips-data`) across restarts and
rebuilds. The frontend container reads `API_BASE_URL` at startup and bakes it
into `config.js`, so the same image works locally and in production — just
change the env var, no rebuild needed for that part.

### Deploying with Render (from GitHub)

Render can build and run these Dockerfiles directly from a connected GitHub
repo — no separate CI setup needed.

1. Push this project to a GitHub repo (`git init`, commit, push).
2. On [render.com](https://render.com), connect your GitHub account, then
   **New → Blueprint** and pick the repo. Render reads `render.yaml` at the
   repo root and proposes both services (`yt-shorts-backend`,
   `yt-shorts-frontend`) automatically.
3. Deploy. In the backend service's **Environment** tab, set
   `OPENAI_API_KEY`.
4. Once the backend is live, copy its URL (something like
   `https://yt-shorts-backend-xxxx.onrender.com`) into the frontend
   service's `API_BASE_URL` env var, then redeploy the frontend.
5. Also update CORS in `backend/app/main.py` to your frontend's Render URL
   instead of `"*"`, then push — Render redeploys automatically on commits
   to your default branch.

No `render.yaml`? You can add the two services manually instead: **New → Web
Service**, connect the repo, set the **Root Directory** to `backend` (or
`frontend`), and Render auto-detects the Dockerfile in that folder.

**Free tier caveats** worth knowing before you rely on this: services spin
down after ~15 minutes idle (the next request wakes it up slowly), there's
no persistent disk on the free plan (rendered clips disappear on
restart/redeploy — upgrade to a paid plan and attach a disk, or push clips
to S3/R2 instead), and free-tier CPU is modest, so Whisper transcription on
anything but short clips will be slow. Good for demos, undersized for real
traffic.

### Other Docker hosts

Any Docker host works the same way. A few common paths:

- **Single VM** (DigitalOcean, Hetzner, EC2, Lambda/RunPod if you want GPU):
  install Docker, copy the repo over, `docker compose up -d --build`, put
  Caddy or nginx in front for HTTPS + your domain (Caddy auto-issues certs
  with near-zero config). Point `API_BASE_URL` at your real domain, e.g.
  `https://api.yourdomain.com`.
- **Fly.io / Railway**: same idea as Render — point them at the Dockerfiles
  as two services, set env vars in their dashboard.
- **Frontend only on Vercel/Netlify/Cloudflare Pages**: these build static
  sites, not run arbitrary Docker containers with entrypoint scripts, so
  `config.js`'s `__API_BASE__` placeholder won't get substituted
  automatically. Simplest fix: hardcode the real backend URL directly in
  `config.js` before deploying, or add a tiny build step that does the same
  substitution the Docker entrypoint does.

Whichever route, remember to tighten CORS in `backend/app/main.py`
(`allow_origins=["*"]` → your actual frontend domain) once this is public.

## API

- `POST /api/process` — body: `{ "youtube_url": "...", "num_clips": 5, "min_clip_seconds": 20, "max_clip_seconds": 60, "burn_captions": true }` → returns a job.
- `GET /api/status/{job_id}` — poll for progress; `clips[]` is populated when `status == "done"`.
- Rendered clips are served statically at `/clips/{job_id}/{clip_id}.mp4`.

## Notes / things to harden before shipping this for real

- **Job store is in-memory** (a Python dict) — fine for local use, but jobs
  vanish on restart and it won't scale past one process. Swap in Redis/Postgres
  for anything multi-user.
- **Background execution** uses FastAPI's `BackgroundTasks`, which runs in the
  same process. For real concurrency (multiple users transcoding at once), use
  a proper task queue (Celery, RQ, or arq) with a worker pool.
- **Long videos**: transcription and rendering time scale with video length.
  For anything over ~30 min, consider chunked transcription or a bigger
  machine — a CPU-only `small` Whisper model will be noticeably slow.
- **Vertical reframe**: the current approach blur-pads the full frame into
  1080x1920 rather than cropping, so nothing important is ever cut off the
  sides. If you want smarter "follow the speaker's face" cropping instead,
  that requires a face/speaker-tracking pass before the ffmpeg step (e.g.
  with a lightweight face detector per frame) — happy to add that as a next
  iteration.
- **Copyright**: this tool processes videos on the uploader's/user's behalf.
  Make sure whoever runs it has rights to download and re-clip the source
  video before deploying this publicly.
- **Costs**: each run makes one LLM call sized to the transcript length, plus
  local compute for Whisper and ffmpeg — no other paid APIs are used.
