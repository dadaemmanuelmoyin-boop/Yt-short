"""Transcribes audio/video using faster-whisper, producing word-level timestamps."""
from dataclasses import dataclass, field
from faster_whisper import WhisperModel

# Loaded lazily and cached across requests — loading the model is the slow part.
_model: WhisperModel | None = None


def get_model(model_size: str = "small", device: str = "auto", compute_type: str = "auto") -> WhisperModel:
    global _model
    if _model is None:
        _model = WhisperModel(model_size, device=device, compute_type=compute_type)
    return _model


@dataclass
class Word:
    start: float
    end: float
    text: str


@dataclass
class Segment:
    start: float
    end: float
    text: str
    words: list[Word] = field(default_factory=list)


def transcribe(video_path: str, model_size: str = "small") -> list[Segment]:
    model = get_model(model_size)
    segments_iter, _info = model.transcribe(
        video_path,
        word_timestamps=True,
        vad_filter=True,  # skips silence, tightens clip boundaries
    )

    segments: list[Segment] = []
    for seg in segments_iter:
        words = [Word(w.start, w.end, w.word) for w in (seg.words or [])]
        segments.append(Segment(start=seg.start, end=seg.end, text=seg.text.strip(), words=words))
    return segments


def segments_to_transcript_text(segments: list[Segment]) -> str:
    """Renders a timestamped transcript the LLM can reason over."""
    lines = []
    for s in segments:
        lines.append(f"[{s.start:.1f}-{s.end:.1f}] {s.text}")
    return "\n".join(lines)
