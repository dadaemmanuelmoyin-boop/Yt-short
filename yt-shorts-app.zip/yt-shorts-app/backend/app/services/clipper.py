"""Cuts clips from the source video and reformats them to 9:16 using ffmpeg.

Strategy for 9:16:
- Blur-pad approach (safe default, works for any source aspect ratio):
  scale the source to fill a 1080x1920 canvas, blur it as background,
  and overlay a sharp, centered, width-fit copy on top.
This avoids cropping out important content (e.g. two people side by side)
while still producing a proper vertical video.
"""
import os
import subprocess
from dataclasses import dataclass

from .transcriber import Segment, Word


@dataclass
class SubtitleStyle:
    font: str = "DejaVu Sans"
    font_size: int = 64
    primary_color: str = "&H00FFFFFF"  # white
    outline_color: str = "&H00000000"  # black
    bold: bool = True


def _format_ass_time(t: float) -> str:
    h = int(t // 3600)
    m = int((t % 3600) // 60)
    s = t % 60
    return f"{h:01d}:{m:02d}:{s:05.2f}"


def build_ass_subtitles(words: list[Word], clip_start: float, out_path: str,
                         style: SubtitleStyle = SubtitleStyle()) -> None:
    """Builds word-grouped karaoke-style captions (few words per line at a time),
    a common short-form-video caption style, timed relative to the clip start."""
    header = f"""[Script Info]
ScriptType: v4.00+
PlayResX: 1080
PlayResY: 1920

[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, OutlineColour, Bold, Alignment, MarginV
Style: Default,{style.font},{style.font_size},{style.primary_color},{style.outline_color},{-1 if style.bold else 0},2,220

[Events]
Format: Layer, Start, End, Style, Text
"""
    lines = []
    # Group words into ~3-word chunks for punchy on-screen captions
    chunk = []
    chunk_start = None
    GROUP_SIZE = 3
    for w in words:
        rel_start = w.start - clip_start
        rel_end = w.end - clip_start
        if rel_end < 0:
            continue
        if chunk_start is None:
            chunk_start = rel_start
        chunk.append(w.text.strip())
        if len(chunk) >= GROUP_SIZE:
            lines.append((chunk_start, rel_end, " ".join(chunk)))
            chunk = []
            chunk_start = None
    if chunk:
        lines.append((chunk_start, chunk_start + 1.5, " ".join(chunk)))

    with open(out_path, "w", encoding="utf-8") as f:
        f.write(header)
        for start, end, text in lines:
            f.write(f"Dialogue: 0,{_format_ass_time(start)},{_format_ass_time(end)},Default,{text}\n")


def render_vertical_clip(
    source_path: str,
    start: float,
    end: float,
    out_path: str,
    subtitle_ass_path: str | None = None,
) -> None:
    duration = end - start

    vf_parts = [
        # background: fill 1080x1920, blurred
        "split=2[bg][fg]",
        "[bg]scale=1080:1920:force_original_aspect_ratio=increase,"
        "crop=1080:1920,gblur=sigma=20[bgblur]",
        # foreground: fit width, centered
        "[fg]scale=1080:-2:force_original_aspect_ratio=decrease[fgscaled]",
        "[bgblur][fgscaled]overlay=(W-w)/2:(H-h)/2[merged]",
    ]
    filter_complex = ";".join(vf_parts)

    final_label = "[merged]"
    if subtitle_ass_path:
        # ass filter must be applied after the overlay, in the same graph
        filter_complex += f";[merged]ass={subtitle_ass_path}[out]"
        final_label = "[out]"

    cmd = [
        "ffmpeg", "-y",
        "-ss", str(start), "-i", source_path,
        "-t", str(duration),
        "-filter_complex", filter_complex,
        "-map", final_label,
        "-map", "0:a?",
        "-c:v", "libx264", "-preset", "veryfast", "-crf", "20",
        "-c:a", "aac", "-b:a", "160k",
        out_path,
    ]
    subprocess.run(cmd, check=True, capture_output=True)


def render_clip_with_captions(
    source_path: str,
    segment_words: list[Word],
    start: float,
    end: float,
    out_path: str,
    work_dir: str,
    burn_captions: bool = True,
) -> None:
    ass_path = None
    if burn_captions and segment_words:
        ass_path = os.path.join(work_dir, f"{os.path.basename(out_path)}.ass")
        build_ass_subtitles(segment_words, start, ass_path)
    render_vertical_clip(source_path, start, end, out_path, subtitle_ass_path=ass_path)
