"""Downloads a YouTube video to local disk using yt-dlp."""
import os
import yt_dlp


def download_video(youtube_url: str, out_dir: str) -> str:
    """Downloads video+audio muxed as mp4. Returns the local file path."""
    os.makedirs(out_dir, exist_ok=True)
    out_template = os.path.join(out_dir, "source.%(ext)s")

    ydl_opts = {
        "format": "bestvideo[ext=mp4][height<=1080]+bestaudio[ext=m4a]/best[ext=mp4]/best",
        "outtmpl": out_template,
        "merge_output_format": "mp4",
        "quiet": True,
        "noplaylist": True,
    }

    with yt_dlp.YoutubeDL(ydl_opts) as ydl:
        info = ydl.extract_info(youtube_url, download=True)
        filepath = ydl.prepare_filename(info)
        # merge_output_format can change the extension after muxing
        base, _ = os.path.splitext(filepath)
        mp4_path = base + ".mp4"
        return mp4_path if os.path.exists(mp4_path) else filepath
