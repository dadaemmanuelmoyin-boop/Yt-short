"""Asks an LLM to pick the best short-form clip candidates from a transcript."""
import json
import os
from openai import OpenAI

from .transcriber import Segment, segments_to_transcript_text

_client: OpenAI | None = None


def get_client() -> OpenAI:
    global _client
    if _client is None:
        _client = OpenAI(api_key=os.environ["OPENAI_API_KEY"])
    return _client


SYSTEM_PROMPT = """You are an expert short-form video editor who finds viral-worthy \
clips inside long-form video transcripts (podcasts, interviews, talks).

Given a timestamped transcript, select the best standalone clips for vertical \
short-form video (TikTok/Reels/YouTube Shorts). A good clip:
- Is a self-contained thought: a hook, story, joke, insight, or hot take that makes \
sense without extra context.
- Has a strong opening line in the first 1-2 seconds (the "hook").
- Falls within the requested duration range.
- Does not cut off mid-sentence at the start or end — snap to the nearest sentence \
boundary in the transcript.

Return ONLY valid JSON, no prose, no markdown fences, matching this schema:
{
  "clips": [
    {"start": <float seconds>, "end": <float seconds>, "title": "<short catchy title>", "reason": "<one sentence on why this works>"}
  ]
}
"""


def select_clips(
    segments: list[Segment],
    num_clips: int = 5,
    min_seconds: int = 20,
    max_seconds: int = 60,
    model: str = "gpt-4o-mini",
) -> list[dict]:
    transcript_text = segments_to_transcript_text(segments)

    user_prompt = (
        f"Pick the {num_clips} best clips.\n"
        f"Each clip must be between {min_seconds} and {max_seconds} seconds long.\n\n"
        f"Transcript:\n{transcript_text}"
    )

    client = get_client()
    response = client.chat.completions.create(
        model=model,
        messages=[
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": user_prompt},
        ],
        temperature=0.4,
        response_format={"type": "json_object"},
    )

    content = response.choices[0].message.content
    data = json.loads(content)
    clips = data.get("clips", [])

    # Basic validation / clamping against actual transcript bounds
    if segments:
        video_end = segments[-1].end
    else:
        video_end = float("inf")

    validated = []
    for c in clips:
        try:
            start = max(0.0, float(c["start"]))
            end = min(video_end, float(c["end"]))
            if end - start < 3:  # discard degenerate clips
                continue
            validated.append({
                "start": start,
                "end": end,
                "title": c.get("title", "Untitled clip"),
                "reason": c.get("reason", ""),
            })
        except (KeyError, ValueError, TypeError):
            continue

    return validated
