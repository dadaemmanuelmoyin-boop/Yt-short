from enum import Enum
from typing import Optional
from pydantic import BaseModel


class JobStatus(str, Enum):
    QUEUED = "queued"
    DOWNLOADING = "downloading"
    TRANSCRIBING = "transcribing"
    SELECTING_CLIPS = "selecting_clips"
    RENDERING = "rendering"
    DONE = "done"
    FAILED = "failed"


class ProcessRequest(BaseModel):
    youtube_url: str
    num_clips: int = 5
    min_clip_seconds: int = 20
    max_clip_seconds: int = 60
    burn_captions: bool = True


class ClipResult(BaseModel):
    id: str
    title: str
    reason: str
    start: float
    end: float
    file_url: Optional[str] = None


class JobState(BaseModel):
    job_id: str
    status: JobStatus
    progress: float = 0.0
    message: str = ""
    error: Optional[str] = None
    clips: list[ClipResult] = []
