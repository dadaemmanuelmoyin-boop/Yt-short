import os
import shutil
import traceback
import uuid

from dotenv import load_dotenv
from fastapi import BackgroundTasks, FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles

from .models import ProcessRequest, JobState, JobStatus, ClipResult
from .services import downloader, transcriber, clip_selector, clipper

load_dotenv()

APP_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
WORK_ROOT = os.path.join(APP_DIR, "app", "work")
STATIC_CLIPS_DIR = os.path.join(APP_DIR, "app", "static", "clips")
os.makedirs(WORK_ROOT, exist_ok=True)
os.makedirs(STATIC_CLIPS_DIR, exist_ok=True)

app = FastAPI(title="YouTube -> Shorts Pipeline")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # tighten this for production
    allow_methods=["*"],
    allow_headers=["*"],
)

app.mount("/clips", StaticFiles(directory=STATIC_CLIPS_DIR), name="clips")

# In-memory job store. Swap for Redis/DB for multi-worker deployments.
JOBS: dict[str, JobState] = {}


def _update(job_id: str, **kwargs):
    job = JOBS[job_id]
    for k, v in kwargs.items():
        setattr(job, k, v)


def run_pipeline(job_id: str, req: ProcessRequest):
    work_dir = os.path.join(WORK_ROOT, job_id)
    os.makedirs(work_dir, exist_ok=True)

    try:
        _update(job_id, status=JobStatus.DOWNLOADING, progress=0.05, message="Downloading video...")
        video_path = downloader.download_video(req.youtube_url, work_dir)

        _update(job_id, status=JobStatus.TRANSCRIBING, progress=0.25, message="Transcribing with Whisper...")
        segments = transcriber.transcribe(video_path)

        _update(job_id, status=JobStatus.SELECTING_CLIPS, progress=0.55, message="Selecting best clips with LLM...")
        picks = clip_selector.select_clips(
            segments,
            num_clips=req.num_clips,
            min_seconds=req.min_clip_seconds,
            max_seconds=req.max_clip_seconds,
        )
        if not picks:
            raise RuntimeError("The model did not return any usable clips.")

        _update(job_id, status=JobStatus.RENDERING, progress=0.7, message="Rendering vertical clips...")
        job_clip_dir = os.path.join(STATIC_CLIPS_DIR, job_id)
        os.makedirs(job_clip_dir, exist_ok=True)

        # Flatten all words once for caption lookups per clip
        all_words = [w for seg in segments for w in seg.words]

        results: list[ClipResult] = []
        for i, pick in enumerate(picks):
            clip_id = f"clip_{i+1}"
            out_file = os.path.join(job_clip_dir, f"{clip_id}.mp4")
            words_in_range = [w for w in all_words if w.start >= pick["start"] and w.end <= pick["end"]]

            clipper.render_clip_with_captions(
                source_path=video_path,
                segment_words=words_in_range,
                start=pick["start"],
                end=pick["end"],
                out_path=out_file,
                work_dir=job_clip_dir,
                burn_captions=req.burn_captions,
            )

            results.append(ClipResult(
                id=clip_id,
                title=pick["title"],
                reason=pick["reason"],
                start=pick["start"],
                end=pick["end"],
                file_url=f"/clips/{job_id}/{clip_id}.mp4",
            ))
            _update(job_id, progress=0.7 + 0.28 * ((i + 1) / len(picks)))

        _update(job_id, status=JobStatus.DONE, progress=1.0, message="Done.", clips=results)

    except Exception as e:  # noqa: BLE001
        traceback.print_exc()
        _update(job_id, status=JobStatus.FAILED, error=str(e), message="Pipeline failed.")
    finally:
        # Clean up the large source video + intermediate work dir, keep only rendered clips
        shutil.rmtree(work_dir, ignore_errors=True)


@app.post("/api/process", response_model=JobState)
def process(req: ProcessRequest, background_tasks: BackgroundTasks):
    if not req.youtube_url:
        raise HTTPException(400, "youtube_url is required")

    job_id = str(uuid.uuid4())
    JOBS[job_id] = JobState(job_id=job_id, status=JobStatus.QUEUED, message="Queued.")

    # Runs in a background thread so the request returns immediately and the
    # frontend can poll /api/status/{job_id}. For real concurrent multi-user
    # load, swap this for a task queue (Celery, RQ, arq) instead.
    background_tasks.add_task(run_pipeline, job_id, req)

    return JOBS[job_id]


@app.get("/api/status/{job_id}", response_model=JobState)
def status(job_id: str):
    job = JOBS.get(job_id)
    if not job:
        raise HTTPException(404, "Job not found")
    return job


@app.get("/api/health")
def health():
    return {"ok": True}
